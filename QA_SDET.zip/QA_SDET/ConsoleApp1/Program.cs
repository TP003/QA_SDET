﻿
using RESTProxy;
using System;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            //string url = string.Format("{0}/search/USA?text={1}", "http://services.groupkt.com/state", "PA");

            string serviceURL = "http://services.groupkt.com/state/get/USA/all";

            Console.WriteLine("************************************************");
            Console.WriteLine(" Select Option from below ");
            Console.WriteLine("************************************************");
            Console.WriteLine("1) Find Largest City and Capital by State Name");
            Console.WriteLine("2) exit ");
            Console.WriteLine("************************************************");

            try
            {

                int number = 0;
                if (int.TryParse(Console.ReadLine(), out number))
                {
                    while (number != 2)
                    {
                        Console.WriteLine("************************************************");
                        Console.WriteLine("Please enter State Name (e.g NJ/New Jersey): ");
                        string input = Console.ReadLine();

                        if (input != string.Empty)
                        {
                            Console.WriteLine("*********** Largest City and Capital for " + input + "*************");

                            ServiceCall svc = new ServiceCall();
                            var state = svc.GetResult(serviceURL, input);
                            if (state != null)
                            {
                                Console.WriteLine("Largest City : " + state.largest_city + Environment.NewLine + "Capital :" + state.capital);
                            }
                            else
                            {
                                Console.WriteLine(" No Record found for  " + input);
                            }
                        }
                        else
                        {
                            Console.WriteLine("Invalid user entry");
                        }
                    }
                }
                else
                {
                    Console.WriteLine("Invalid Choice, Please try again");
                    Console.ReadLine();
                }
                
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

        }

    }
}