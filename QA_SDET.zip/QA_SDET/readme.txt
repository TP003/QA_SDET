QA_SDET
Developed by : Tejas Patel/ 01.11.2018
===========================================
QA_SDET solution includes following projects
1) ConsoleApp1 - Console App
2) RESTProxy  - Class Library 
	- Newtonsoft.Json
3) UnitTestProject1 - Unit Test 



