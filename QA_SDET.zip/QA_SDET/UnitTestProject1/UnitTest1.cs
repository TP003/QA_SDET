﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using RESTProxy;

namespace UnitTestProject1
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void Test_001_Service_Test()
        {
            string serviceURL = "http://services.groupkt.com/state/get/XYZ/all";
            string input = "NJ";
           
            ServiceCall svc = new ServiceCall();
            var state = svc.GetResult(serviceURL, input);

            Assert.Equals(state, null);
        }

        [TestMethod]
        public void Test_002_Service_Test_By_RandomString()
        {
            string serviceURL = "http://services.groupkt.com/state/get/XYZ/all";
            string input = "XYZ";
            string expected = "Trenton";

            ServiceCall svc = new ServiceCall();
            var state = svc.GetResult(serviceURL, input);

            Assert.AreEqual(expected, state.capital);
        }

        [TestMethod]
        public void Test_003_Capital_By_Abr()
        {
            string serviceURL = "http://services.groupkt.com/state/get/USA/all";
            string input = "NJ";
            string expected = "Trenton";

            ServiceCall svc = new ServiceCall();
            var state = svc.GetResult(serviceURL, input);

            Assert.AreEqual(expected, state.capital);
        }

        [TestMethod]
        public void Test_004_Capital_By_Name()
        {
            string serviceURL = "http://services.groupkt.com/state/get/USA/all";
            string input = "New Jersey";
            string expected = "XYZ"; //Trenton

            ServiceCall svc = new ServiceCall();
            var state = svc.GetResult(serviceURL, input);

            Assert.AreEqual(expected, state.capital);
        }
    }
}
