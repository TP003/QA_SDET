﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace RESTProxy
{
    public class ServiceCall
    {
        public Result GetResult(string url, string input)
        {
            Task<RootObject> task = GetDetails(url);
            task.Wait();
            Result state = task.Result.RestResponse.result.FirstOrDefault(x => x.abbr == input.ToUpper() || x.name.ToLower() == input.ToLower().Trim());
            return state;
        }
        private async Task<RootObject> GetDetails(string url)
        {
            using (var client = new HttpClient())
            {

                HttpResponseMessage response = await client.GetAsync(url);
                if (response.IsSuccessStatusCode)
                {
                    string result = await response.Content.ReadAsStringAsync();
                    RootObject rootResult = JsonConvert.DeserializeObject<RootObject>(result);
                    return rootResult;
                }
                else
                {
                    return null;
                }
            }
        }
    }

    public class Result
    {
        public int Id { get; set; }
        public string country { get; set; }
        public string name { get; set; }
        public string abbr { get; set; }
        public string area { get; set; }
        public string largest_city { get; set; }
        public string capital { get; set; }
    }

    public class RestResponse
    {
        public List<string> messages { get; set; }
        public List<Result> result { get; set; }
    }

    public class RootObject
    {
        public RestResponse RestResponse { get; set; }
    }
}
